<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2026 adm93rus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'ManagerButtons
==============

Dashboard button groups for MODX Revolution 3.

Create sets of buttons and links, restrict them by user group, and show them
as a dashboard widget. The manager UI uses VueTools (Vue 3 + PrimeVue) and
follows the active VueTools theme.

Requirements
------------
- MODX Revolution 3.0.0+
- PHP 8.1+
- VueTools 1.2.0+ (theme support)

Install VueTools first, then ManagerButtons, from Extras → Installer
(upload the transport zip). Sign in again if the menu item is missing:
setup adds the managerbuttons permission to the Administrator policy.
The widget is placed on the Default dashboard.

Repository: https://github.com/adm93rus/ManagerButtons
Documentation: https://docs.modx.pro/components/managerbuttons
',
    'changelog' => '# Changelog

## [1.2.1-pl] - 2026-09-22

### Fixed
- Button list caption for the description column is taken from the component lexicon files, so a stale manager lexicon cache no longer shows the raw key
- Edit and delete actions on a button row use the manager Font Awesome icons

## [1.2.0-pl] - 2026-09-22

### Added
- Button description under the title
- Per-button background color
- General settings for the default background and text color. With no background, buttons are blue with white text

## [1.1.1-pl] - 2026-09-22

### Fixed
- Groups saved to the database stayed out of the list on MySQL 8 and MariaDB: rank is reserved, and unquoted ORDER BY rank / MAX(rank) failed
- Manager page padding, toolbar spacing, and create dialogs follow the VueTools sample

## [1.1.0-pl] - 2026-09-22

### Added
- Full Font Awesome 5 icon set from the MODX 3 manager
- managerbuttons permission on the Administrator policy
- Bulk delete, search, and pagination
- Widget property group_id

## [1.0.0-pl] - 2026-09-21

### Added
- Button groups with a 4-column dashboard grid
- Access control by MODX user groups (Administrators always have access)
- Buttons with name, link, Font Awesome 5 icon, and width from 1 to 4 columns
- Export and import of a group as JSON (move to another site or duplicate)
- VueTools-based manager UI and dashboard widget (theme from `vuetools.theme`)
- MIT license
',
    'requires' => 
    array (
      'php' => '>=8.1.0',
      'modx' => '>=3.0.0',
      'vuetools' => '>=1.2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'fcda7126ed8e233a1b4069bb0016bab8',
      'native_key' => 'managerbuttons',
      'filename' => 'MODX/Revolution/modNamespace/4c2253f96772be92fb521e1dee6a3b1f.vehicle',
      'namespace' => 'managerbuttons',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'd65ab87da13ec5f86c190d7cbf7fa69f',
      'native_key' => 'd65ab87da13ec5f86c190d7cbf7fa69f',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/beffb6b40c5a57f67c06fef3230e846f.vehicle',
      'namespace' => 'managerbuttons',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'e8fa81e0237c04dc30de85c941793d7c',
      'native_key' => 'e8fa81e0237c04dc30de85c941793d7c',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/bdf77e1201549fe85be4c063835d9245.vehicle',
      'namespace' => 'managerbuttons',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '75550494b3218f97517b959a16c0bf02',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/b55f8a3c8532e6e652ed3131d68d7db7.vehicle',
      'namespace' => 'managerbuttons',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'c4285309b9eb882ed021e6256b7928e8',
      'native_key' => 'ManagerButtons',
      'filename' => 'MODX/Revolution/modMenu/29eb5000ffc6b062e927bd53b70be69d.vehicle',
      'namespace' => 'managerbuttons',
    ),
  ),
);
