<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2026 adm93rus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'ManagerButtons
==============

Группы кнопок и ссылок на панели управления MODX 3.

Наборы выводятся виджетом на дашборде. У кнопки есть название, ссылка,
иконка Font Awesome 5, ширина от 1 до 4 колонок, короткое описание и цвет.
Набор можно ограничить группами пользователей, экспортировать в JSON
и перенести на другой сайт.

Требования
----------
- MODX Revolution 3.0+
- PHP 8.1+
- VueTools 1.2.0+

Сначала установите VueTools, затем этот пакет: Приложения → Установщик.
Если пункта меню нет, выйдите из панели и войдите снова.

Репозиторий: https://github.com/adm93rus/ManagerButtons
Инструкция: https://docs.modx.pro/components/managerbuttons
',
    'changelog' => 'ManagerButtons 1.2.1-pl
22 сентября 2026

Первый публичный выпуск.

- Группы кнопок на панели управления, сетка из четырёх колонок
- Доступ по группам пользователей: администраторы видят все наборы
- Название, ссылка, иконка, ширина, описание и свой цвет кнопки
- Общий цвет фона и текста
- Экспорт и импорт набора
- Виджет на панели управления
',
    'requires' => 
    array (
      'php' => '>=8.1.0',
      'modx' => '>=3.0.0',
      'vuetools' => '>=1.2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'c348edce11a363b9a0183efa9b6632dc',
      'native_key' => 'managerbuttons',
      'filename' => 'MODX/Revolution/modNamespace/c2ee64356495c034dfd8ada3b6f0dee2.vehicle',
      'namespace' => 'managerbuttons',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'd941bb89bd4d3452ff52a20d7da53072',
      'native_key' => 'd941bb89bd4d3452ff52a20d7da53072',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/669fa1820f2bf5673fcae12747b68796.vehicle',
      'namespace' => 'managerbuttons',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'c9c81a6b1721a9b7c5feb2dd57ab6860',
      'native_key' => 'c9c81a6b1721a9b7c5feb2dd57ab6860',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/61faef68e8d27bdfffec5a9e12231159.vehicle',
      'namespace' => 'managerbuttons',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'a91b961ee9bb96592491d601e6163482',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/f8ad09f4cb05fda0fdc0c41dfab71632.vehicle',
      'namespace' => 'managerbuttons',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '03a943841ee8b8c8b3c801430d019cb2',
      'native_key' => 'ManagerButtons',
      'filename' => 'MODX/Revolution/modMenu/408faae07dd151e3bdc038268cc718e6.vehicle',
      'namespace' => 'managerbuttons',
    ),
  ),
);
