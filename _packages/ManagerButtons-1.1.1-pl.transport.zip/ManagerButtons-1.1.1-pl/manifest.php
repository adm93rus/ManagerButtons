<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2026 adm93rus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'ManagerButtons
==============

Dashboard button groups for MODX Revolution 3.

Create sets of buttons and links, restrict them by user group, and show them
as a dashboard widget. The manager UI uses VueTools (Vue 3 + PrimeVue) and
follows the active VueTools theme.

Requirements
------------
- MODX Revolution 3.0.0+
- PHP 8.1+
- VueTools 1.2.0+ (theme support)

Install VueTools first, then ManagerButtons, from Extras → Installer
(upload the transport zip). Sign in again if the menu item is missing:
setup adds the managerbuttons permission to the Administrator policy.
The widget is placed on the Default dashboard.

Repository: https://github.com/adm93rus/ManagerButtons
Documentation: https://docs.modx.pro/components/managerbuttons
',
    'changelog' => '# Changelog

## [1.1.1-pl] - 2026-09-22

### Fixed
- Groups saved to the database stayed out of the list on MySQL 8 and MariaDB: rank is reserved, and unquoted ORDER BY rank / MAX(rank) failed
- Manager page padding, toolbar spacing, and create dialogs follow the VueTools sample

## [1.1.0-pl] - 2026-09-22

### Added
- Full Font Awesome 5 icon set from the MODX 3 manager
- managerbuttons permission on the Administrator policy
- Bulk delete, search, and pagination
- Widget property group_id

## [1.0.0-pl] - 2026-09-21

### Added
- Button groups with a 4-column dashboard grid
- Access control by MODX user groups (Administrators always have access)
- Buttons with name, link, Font Awesome 5 icon, and width from 1 to 4 columns
- Export and import of a group as JSON (move to another site or duplicate)
- VueTools-based manager UI and dashboard widget (theme from `vuetools.theme`)
- MIT license
',
    'requires' => 
    array (
      'php' => '>=8.1.0',
      'modx' => '>=3.0.0',
      'vuetools' => '>=1.2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '66b549f2c7039a15ed756603e116764f',
      'native_key' => 'managerbuttons',
      'filename' => 'MODX/Revolution/modNamespace/8fd40e0c2eb2b0d73955ffa172ec5373.vehicle',
      'namespace' => 'managerbuttons',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '8233ddc2eebe8f5b5719a2a504a32ad5',
      'native_key' => '8233ddc2eebe8f5b5719a2a504a32ad5',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/ddae80d8828cf9468ca299dedf5966d1.vehicle',
      'namespace' => 'managerbuttons',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'd6fb84b079fddf03d575ba24178e1beb',
      'native_key' => 'd6fb84b079fddf03d575ba24178e1beb',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/6c95570f79725e57ef65d71b5a3d1328.vehicle',
      'namespace' => 'managerbuttons',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '753575c4e1ed16c1562c974b2d4355a1',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/0a5ba7bc4e389814bbcd93cfb4eb2494.vehicle',
      'namespace' => 'managerbuttons',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'c1c2cf83f2923ee7898babceada02565',
      'native_key' => 'ManagerButtons',
      'filename' => 'MODX/Revolution/modMenu/abfc7f6d5065bfd9c936204dd7c8a6bf.vehicle',
      'namespace' => 'managerbuttons',
    ),
  ),
);
