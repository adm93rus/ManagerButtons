<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2026 adm93rus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'ManagerButtons
==============

Dashboard button groups for MODX Revolution 3.

Create sets of buttons and links, restrict them by user group, and show them
as a dashboard widget. The manager UI uses VueTools (Vue 3 + PrimeVue) and
follows the active VueTools theme.

Requirements
------------
- MODX Revolution 3.0.0+
- PHP 8.1+
- VueTools 1.2.0+ (theme support)

Install VueTools first, then ManagerButtons, from Extras → Installer
(upload the transport zip). Sign in again if the menu item is missing:
setup adds the managerbuttons permission to the Administrator policy.
The widget is placed on the Default dashboard.

Repository: https://github.com/adm93rus/ManagerButtons
Documentation: https://docs.modx.pro/components/managerbuttons
',
    'changelog' => '# Changelog

## [1.2.0-pl] - 2026-09-22

### Added
- Button description under the title
- Per-button background color
- General settings for the default background and text color. With no background, buttons are gray

## [1.1.1-pl] - 2026-09-22

### Fixed
- Groups saved to the database stayed out of the list on MySQL 8 and MariaDB: rank is reserved, and unquoted ORDER BY rank / MAX(rank) failed
- Manager page padding, toolbar spacing, and create dialogs follow the VueTools sample

## [1.1.0-pl] - 2026-09-22

### Added
- Full Font Awesome 5 icon set from the MODX 3 manager
- managerbuttons permission on the Administrator policy
- Bulk delete, search, and pagination
- Widget property group_id

## [1.0.0-pl] - 2026-09-21

### Added
- Button groups with a 4-column dashboard grid
- Access control by MODX user groups (Administrators always have access)
- Buttons with name, link, Font Awesome 5 icon, and width from 1 to 4 columns
- Export and import of a group as JSON (move to another site or duplicate)
- VueTools-based manager UI and dashboard widget (theme from `vuetools.theme`)
- MIT license
',
    'requires' => 
    array (
      'php' => '>=8.1.0',
      'modx' => '>=3.0.0',
      'vuetools' => '>=1.2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '0507a56af29b52baa373ea2370d4d024',
      'native_key' => 'managerbuttons',
      'filename' => 'MODX/Revolution/modNamespace/e0c7399face9c5c7d6c038452e4da519.vehicle',
      'namespace' => 'managerbuttons',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'e9dc49fd2b4d4515d0e9624059f9fbb7',
      'native_key' => 'e9dc49fd2b4d4515d0e9624059f9fbb7',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/db97c9692800e9e2de6eaedaa236340b.vehicle',
      'namespace' => 'managerbuttons',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '73357c7c3128a97735fbb82859ff607a',
      'native_key' => '73357c7c3128a97735fbb82859ff607a',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/0468a8a67beb993f6b6faf780396775b.vehicle',
      'namespace' => 'managerbuttons',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'cc507dd719981b15cac31cf03cce42da',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/627c653c0214412470fa8accfbdf8418.vehicle',
      'namespace' => 'managerbuttons',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '605060cc98de51976f9e36a8f2eefa03',
      'native_key' => 'ManagerButtons',
      'filename' => 'MODX/Revolution/modMenu/1e85830b57fa2d36b897a30ef7f61a94.vehicle',
      'namespace' => 'managerbuttons',
    ),
  ),
);
