<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2026 adm93rus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'ManagerButtons
==============

Dashboard button groups for MODX Revolution 3.

Create sets of buttons and links, restrict them by user group, and show them
as a dashboard widget. The manager UI uses VueTools (Vue 3 + PrimeVue) and
follows the active VueTools theme.

Requirements
------------
- MODX Revolution 3.0.0+
- PHP 8.1+
- VueTools 1.2.0+ (theme support)

Install VueTools first, then ManagerButtons, from Extras → Installer
(upload the transport zip). Sign in again if the menu item is missing:
setup adds the managerbuttons permission to the Administrator policy.
The widget is placed on the Default dashboard.

Repository: https://github.com/adm93rus/ManagerButtons
Documentation: https://docs.modx.pro/components/managerbuttons
',
    'changelog' => '# Changelog

## [1.2.0-pl] - 2026-09-22

### Added
- Button description under the title
- Per-button background color
- General settings for the default background and text color. With no background, buttons are blue with white text

## [1.1.1-pl] - 2026-09-22

### Fixed
- Groups saved to the database stayed out of the list on MySQL 8 and MariaDB: rank is reserved, and unquoted ORDER BY rank / MAX(rank) failed
- Manager page padding, toolbar spacing, and create dialogs follow the VueTools sample

## [1.1.0-pl] - 2026-09-22

### Added
- Full Font Awesome 5 icon set from the MODX 3 manager
- managerbuttons permission on the Administrator policy
- Bulk delete, search, and pagination
- Widget property group_id

## [1.0.0-pl] - 2026-09-21

### Added
- Button groups with a 4-column dashboard grid
- Access control by MODX user groups (Administrators always have access)
- Buttons with name, link, Font Awesome 5 icon, and width from 1 to 4 columns
- Export and import of a group as JSON (move to another site or duplicate)
- VueTools-based manager UI and dashboard widget (theme from `vuetools.theme`)
- MIT license
',
    'requires' => 
    array (
      'php' => '>=8.1.0',
      'modx' => '>=3.0.0',
      'vuetools' => '>=1.2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '10f5c3cf8408e5896b25dc84fe2104ec',
      'native_key' => 'managerbuttons',
      'filename' => 'MODX/Revolution/modNamespace/55f98911d90f081ed403c08a14014790.vehicle',
      'namespace' => 'managerbuttons',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '088ace602afe8f25e8ecfac5091633ca',
      'native_key' => '088ace602afe8f25e8ecfac5091633ca',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/7af116118e83ae59f8c8ff44413f5eb6.vehicle',
      'namespace' => 'managerbuttons',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'dff567f410a7d3fb76a6b4884d2e0302',
      'native_key' => 'dff567f410a7d3fb76a6b4884d2e0302',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/31f0e759bcedaad1787ea8b3249179b5.vehicle',
      'namespace' => 'managerbuttons',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'e45749f8d69e821b25e65cf6e8d96ea7',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/0c5d5c13ec3a99c923cc3e1c32387002.vehicle',
      'namespace' => 'managerbuttons',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '6a24d21754c70cfd06759d1b3d8b1f50',
      'native_key' => 'ManagerButtons',
      'filename' => 'MODX/Revolution/modMenu/fed6fce7371bd79c97f2d3cb595a73f1.vehicle',
      'namespace' => 'managerbuttons',
    ),
  ),
);
